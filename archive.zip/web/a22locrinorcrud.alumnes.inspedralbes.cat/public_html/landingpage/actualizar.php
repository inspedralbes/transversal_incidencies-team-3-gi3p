
<?php
$mysqli = include_once "conexion.php";
$id = $_POST["idInc"];
$nouDep = $_POST["departament"];
$nouDesc = $_POST["descripcion"];
$nouPrior = $_POST["prioridad"];
$timestamp = $_POST["data"];


$sentencia = $mysqli->prepare("UPDATE INCIDENCIA SET descripcio = ?, departament = ?, prioritat = ?, data = ?
WHERE idInc = ?;");
$sentencia->bind_param("ssssi", $nouDesc, $nouDep, $nouPrior,$timestamp, $id);
$sentencia->execute();
header("Location: llistaincidencies.php");
?>